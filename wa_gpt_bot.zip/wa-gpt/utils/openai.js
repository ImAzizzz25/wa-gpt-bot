// Dummy content for utils/openai.js
